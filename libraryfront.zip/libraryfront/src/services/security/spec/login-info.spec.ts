import { AuthLoginInfo } from '../login-info';

describe('LoginInfo', () => {
  it('should create an instance', () => {
    // @ts-ignore
    expect(new AuthLoginInfo()).toBeTruthy();
  });
});
