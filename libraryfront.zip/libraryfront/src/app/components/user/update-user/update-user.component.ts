import {Component, Input, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {UserService} from '../../../../services/user.service';
import {AuthService} from '../../../../services/security/auth.service';
import {Router} from '@angular/router';
import {User} from '../../../../models/user';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private userService: UserService, private authService: AuthService, private router: Router) { }

  forms: FormGroup;

  @Input()
  user: User;

  private messageError: string;

  ngOnInit() {
    this.initform();
  }

  private initform() {
    this.forms = this.formBuilder.group(
      {
        firstName: this.user.firstName,
        lastName: this.user.lastName,
        birthday: this.user.birthday,
        city: this.user.city,
        postalCode: this.user.postalCode,
        email: this.user.email,
        phone: this.user.phone,
        password: new FormControl(),
        address: this.user.address,
      });
  }

  updateUser() {
    console.log(this.forms.value);
    this.authService.saveUser(this.forms)
      .subscribe(
        response => {
          console.log('response: ', response);
        },
        err => {
          console.log('Error: ', err.error.message);
          this.messageError = err.error.message;
        });

    this.userService.updateUser(this.forms)
      .subscribe(
        response => {
          console.log('response: ', response);
        },
        err => {
          console.log('Error: ', err.error.message);
          this.messageError = err.error.message;
        });
  }

}
