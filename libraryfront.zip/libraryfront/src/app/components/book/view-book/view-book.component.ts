import {Component, Input, OnInit} from '@angular/core';
import {Book} from '../../../../models/book';
import {BookService} from '../../../../services/book.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-view-book',
  templateUrl: './view-book.component.html',
  styleUrls: ['./view-book.component.css']
})
export class ViewBookComponent implements OnInit {

  @Input() selectedBook: Book;

  book: Book;

  constructor(private bookService: BookService, private route:Router) { }

  ngOnInit(){
   this.book = this.selectedBook;
  }


}
