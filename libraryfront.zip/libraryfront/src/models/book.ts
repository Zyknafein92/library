export interface Book {
  id?: number;
  title?: string;
  author?: string;
  parution?: string;
  description?: string;
  gender?: string;
  picture?: string;
  avaible?: boolean;
  libraryID?: string;
  libraryName?: string;
}













