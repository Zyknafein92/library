export interface Borrow {
 id?: number;
 userID?: string;
 bookID?: string;
 dateStart?: Date;
 dateEnd?: Date;
 dateExtend?: Date;
 isExtend?: boolean;
}
